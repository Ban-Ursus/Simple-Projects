package com.mikepenz.materialdrawer.model;

/**
 * Created by mikepenz on 03.02.15.
 */
public class ToggleDrawerItem extends AbstractToggleableDrawerItem<ToggleDrawerItem> {

}
