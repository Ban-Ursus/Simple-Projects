package com.test.web.common.bean;

import java.util.Calendar;

public class TeacherBean {

	private String teacherId;
	private String teacherPw;
	private Calendar teacherJoinDate;
	private String teacherName;
	private String teacherBirthnum;
	private String teacherGender;
	private String teacherCellphone;
	private String teacherCareer;
	private String teacherInfo;
	private String teacherCheck;

	public String getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(String teacherId) {
		this.teacherId = teacherId;
	}

	public String getTeacherPw() {
		return teacherPw;
	}

	public void setTeacherPw(String teacherPw) {
		this.teacherPw = teacherPw;
	}

	public Calendar getTeacherJoinDate() {
		return teacherJoinDate;
	}

	public void setTeacherJoinDate(Calendar teacherJoinDate) {
		this.teacherJoinDate = teacherJoinDate;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getTeacherBirthnum() {
		return teacherBirthnum;
	}

	public void setTeacherBirthnum(String teacherBirthnum) {
		this.teacherBirthnum = teacherBirthnum;
	}

	public String getTeacherGender() {
		return teacherGender;
	}

	public void setTeacherGender(String teacherGender) {
		this.teacherGender = teacherGender;
	}

	public String getTeacherCellphone() {
		return teacherCellphone;
	}

	public void setTeacherCellphone(String teacherCellphone) {
		this.teacherCellphone = teacherCellphone;
	}

	public String getTeacherCareer() {
		return teacherCareer;
	}

	public void setTeacherCareer(String teacherCareer) {
		this.teacherCareer = teacherCareer;
	}

	public String getTeacherInfo() {
		return teacherInfo;
	}

	public void setTeacherInfo(String teacherInfo) {
		this.teacherInfo = teacherInfo;
	}

	public String getTeacherCheck() {
		return teacherCheck;
	}

	public void setTeacherCheck(String teacherCheck) {
		this.teacherCheck = teacherCheck;
	}

	

}
