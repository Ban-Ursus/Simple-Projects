package com.test.web.common.bean;

public class CommonBean {
	
	private String no;
	private String boardNo;
	private String regDate;
	
	
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getBoardNo() {
		return boardNo;
	}
	public String getNo() {
		return no;
	}
	public void setBoardNo(String boardNo) {
		this.boardNo = boardNo;
	}
	public void setNo(String no) {
		this.no = no;
	}
	
}
